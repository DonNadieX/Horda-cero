# Horda Cero

Prototipo de shooter cooperativo de zombis en primera persona para Godot 4.x (PC y Android).
Todo se genera por código: no hay modelos, texturas ni audios externos.

## Cómo abrirlo
Abre `project.godot` con Godot 4.3 o más nuevo y pulsa Ejecutar.

## Objetivo
Cruza 240 m de calle infestada y entra al refugio de luz verde.

## Controles (Android)
- Mitad izquierda: joystick de movimiento
- Arrastrar a la derecha: apuntar
- Botones: FUEGO, RECARGAR, ARMA, EMPUJAR, SALTO, CURAR

## Controles (PC)
WASD mover · flechas o ratón apuntar · F o clic disparar · E empujar ·
R recargar · Q curar · 1/2/3 armas · Espacio saltar

## Enemigos
- Común: corre en grupo
- Acechador (ojos rojos): salta desde lejos
- Hinchado (verde): explota, te ciega y atrae una horda
- Bruto: enorme, aguanta mucho y te lanza por los aires

## Archivos
- `scripts/main.gd`: nivel, director de hordas, efectos
- `scripts/player.gd`: jugador y armas
- `scripts/zombie.gd`: infectados
- `scripts/bot.gd`: compañeros con IA
- `scripts/hud.gd`: interfaz y controles táctiles
- `scripts/sfx.gd`: sonidos generados por código
