extends Control
# Interfaz: salud, municion, companeros, mensajes, controles tactiles y pantallas de inicio/fin.

var game
var player
var font: Font
var show_touch := false
var move_vec := Vector2.ZERO
var fire_held := false
var joy_id := -1
var joy_origin := Vector2.ZERO
var joy_pos := Vector2.ZERO
var look_ids := {}
var btn_ids := {}
var flash := 0.0
var msg_text := ""
var msg_t := 0.0
var msg_color := Color.WHITE
var overlay: ColorRect
var title: Label
var body: Label
var btn: Button


func setup(g, p) -> void:
	game = g
	player = p
	font = ThemeDB.fallback_font
	show_touch = OS.has_feature("mobile") or DisplayServer.is_touchscreen_available()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	overlay = ColorRect.new()
	overlay.color = Color(0.0, 0.0, 0.0, 0.8)
	add_child(overlay)
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	overlay.add_child(cc)
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 22)
	cc.add_child(vb)
	title = Label.new()
	title.add_theme_font_size_override("font_size", 72)
	title.add_theme_color_override("font_color", Color(0.85, 0.15, 0.1))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = "HORDA CERO"
	vb.add_child(title)
	body = Label.new()
	body.add_theme_font_size_override("font_size", 24)
	body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.text = "Cruza la calle infestada y llega al refugio.\nTus compañeros te cubren: no los dejes atrás.\n\nTáctil: joystick a la izquierda, arrastra a la derecha para apuntar\nTeclado: WASD mover · flechas o ratón apuntar · F o clic disparar\nE empujar · R recargar · Q curar · 1-2-3 armas · Espacio saltar"
	vb.add_child(body)
	btn = Button.new()
	btn.text = "JUGAR"
	btn.add_theme_font_size_override("font_size", 36)
	btn.custom_minimum_size = Vector2(320.0, 90.0)
	btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	btn.pressed.connect(_on_btn)
	vb.add_child(btn)
	btn.grab_focus.call_deferred()


func _on_btn() -> void:
	if game.finished:
		get_tree().reload_current_scene()
	else:
		overlay.visible = false
		game.start()


func show_end(win: bool, kills: int, headshots: int, secs: float) -> void:
	fire_held = false
	move_vec = Vector2.ZERO
	joy_id = -1
	title.text = "¡REFUGIO ALCANZADO!" if win else "HAS MUERTO"
	title.add_theme_color_override("font_color", Color(0.3, 0.9, 0.4) if win else Color(0.85, 0.15, 0.1))
	body.text = "Infectados eliminados: %d\nDisparos a la cabeza: %d\nTiempo: %d:%02d" % [kills, headshots, int(secs) / 60, int(secs) % 60]
	btn.text = "JUGAR DE NUEVO"
	overlay.visible = true
	btn.grab_focus.call_deferred()


func msg(text: String, dur := 3.0, color := Color.WHITE) -> void:
	msg_text = text
	msg_t = dur
	msg_color = color


func _buttons() -> Dictionary:
	var w := size.x
	var h := size.y
	return {
		"fire": [Vector2(w - 170.0, h - 180.0), 82.0, "FUEGO"],
		"reload": [Vector2(w - 340.0, h - 100.0), 52.0, "RECARGAR"],
		"jump": [Vector2(w - 70.0, h - 340.0), 50.0, "SALTO"],
		"shove": [Vector2(w - 230.0, h - 360.0), 52.0, "EMPUJAR"],
		"swap": [Vector2(w - 370.0, h - 240.0), 52.0, "ARMA"],
		"heal": [Vector2(w - 80.0, h - 470.0), 46.0, "CURAR"],
	}


func _button_at(p: Vector2) -> String:
	var bs := _buttons()
	for k in bs:
		var b: Array = bs[k]
		var c: Vector2 = b[0]
		if p.distance_to(c) <= float(b[1]) * 1.1:
			return str(k)
	return ""


func _press(b: String) -> void:
	match b:
		"fire":
			fire_held = true
		"reload":
			player.start_reload()
		"jump":
			player.want_jump = true
		"shove":
			player.shove()
		"swap":
			player.next_weapon()
		"heal":
			player.heal()


func _input(event: InputEvent) -> void:
	if game == null or not game.playing:
		return
	if event is InputEventScreenTouch:
		show_touch = true
		if event.pressed:
			var b := _button_at(event.position)
			if b != "":
				btn_ids[event.index] = b
				_press(b)
			elif event.position.x < size.x * 0.4 and joy_id == -1:
				joy_id = event.index
				joy_origin = event.position
				joy_pos = event.position
			else:
				look_ids[event.index] = true
		else:
			if btn_ids.has(event.index):
				if btn_ids[event.index] == "fire":
					fire_held = false
				btn_ids.erase(event.index)
			if event.index == joy_id:
				joy_id = -1
				move_vec = Vector2.ZERO
			look_ids.erase(event.index)
	elif event is InputEventScreenDrag:
		if event.index == joy_id:
			joy_pos = event.position
			var v: Vector2 = (joy_pos - joy_origin) / 90.0
			move_vec = v.limit_length(1.0)
		elif look_ids.has(event.index) or (btn_ids.has(event.index) and btn_ids[event.index] == "fire"):
			player.add_look(event.relative * 0.0045)


func _process(delta: float) -> void:
	flash = maxf(0.0, flash - delta * 1.5)
	msg_t = maxf(0.0, msg_t - delta)
	queue_redraw()


func _bar(pos: Vector2, sz: Vector2, frac: float, color: Color) -> void:
	draw_rect(Rect2(pos, sz), Color(0.0, 0.0, 0.0, 0.55))
	draw_rect(Rect2(pos + Vector2(2.0, 2.0), Vector2((sz.x - 4.0) * clampf(frac, 0.0, 1.0), sz.y - 4.0)), color)


func _hp_color(v: float) -> Color:
	if v >= 40.0:
		return Color(0.25, 0.8, 0.3)
	if v >= 20.0:
		return Color(0.9, 0.7, 0.15)
	return Color(0.9, 0.2, 0.15)


func _draw() -> void:
	if game == null:
		return
	var w := size.x
	var h := size.y
	var bile_v: float = player.bile_t
	if bile_v > 0.0:
		draw_rect(Rect2(0.0, 0.0, w, h), Color(0.35, 0.5, 0.1, minf(0.6, bile_v * 0.2)))
	if flash > 0.0:
		draw_rect(Rect2(0.0, 0.0, w, h), Color(0.8, 0.0, 0.0, flash * 0.5))
	if not game.playing:
		return

	# Mira
	var c := Vector2(w, h) * 0.5
	var cw := Color(1.0, 1.0, 1.0, 0.85)
	draw_line(c + Vector2(-13.0, 0.0), c + Vector2(-5.0, 0.0), cw, 2.0)
	draw_line(c + Vector2(5.0, 0.0), c + Vector2(13.0, 0.0), cw, 2.0)
	draw_line(c + Vector2(0.0, -13.0), c + Vector2(0.0, -5.0), cw, 2.0)
	draw_line(c + Vector2(0.0, 5.0), c + Vector2(0.0, 13.0), cw, 2.0)

	# Salud propia
	var php: float = player.hp
	_bar(Vector2(24.0, 20.0), Vector2(270.0, 30.0), php / 100.0, _hp_color(php))
	draw_string(font, Vector2(34.0, 42.0), "SALUD %d" % int(php), HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color.WHITE)
	draw_string(font, Vector2(24.0, 74.0), "Botiquines: %d" % int(player.medkits), HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1.0, 0.6, 0.6))

	# Companeros
	var y := 92.0
	for bt in game.bots:
		var bhp: float = bt.hp
		_bar(Vector2(24.0, y), Vector2(190.0, 22.0), bhp / 100.0, _hp_color(bhp))
		var label: String = bt.bname
		if bt.down:
			label = "%s CAÍDO %d%%" % [bt.bname, int(float(bt.revive_p) * 100.0)]
		draw_string(font, Vector2(32.0, y + 17.0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color.WHITE)
		y += 28.0

	# Arma y municion
	var wp: Dictionary = player.weapons[player.cur]
	var res := "--"
	if int(wp["reserve"]) >= 0:
		res = str(wp["reserve"])
	var ammo := "%d / %s" % [int(wp["mag"]), res]
	if float(player.reload_t) > 0.0:
		ammo = "RECARGANDO..."
	draw_string(font, Vector2(w - 324.0, 40.0), str(wp["name"]), HORIZONTAL_ALIGNMENT_RIGHT, 300, 22, Color(0.9, 0.9, 0.9))
	draw_string(font, Vector2(w - 324.0, 76.0), ammo, HORIZONTAL_ALIGNMENT_RIGHT, 300, 32, Color.WHITE)

	# Progreso hacia el refugio
	var prog: float = clampf(-float(player.global_position.z) / float(game.STREET_LEN), 0.0, 1.0)
	_bar(Vector2(w * 0.5 - 160.0, 20.0), Vector2(320.0, 16.0), prog, Color(0.9, 0.5, 0.15))
	var left: int = int(maxf(0.0, float(game.STREET_LEN) + float(player.global_position.z)))
	draw_string(font, Vector2(w * 0.5 - 160.0, 58.0), "REFUGIO A %d m" % left, HORIZONTAL_ALIGNMENT_CENTER, 320, 18, Color(1.0, 0.85, 0.6))

	# Mensajes
	if msg_t > 0.0:
		var mc := msg_color
		mc.a = minf(1.0, msg_t)
		draw_string(font, Vector2(0.0, h * 0.24), msg_text, HORIZONTAL_ALIGNMENT_CENTER, w, 34, mc)
	if player.down and not player.dead:
		draw_string(font, Vector2(0.0, h * 0.6), "INCAPACITADO — reanimando %d%%" % int(float(player.revive_p) * 100.0), HORIZONTAL_ALIGNMENT_CENTER, w, 30, Color(1.0, 0.4, 0.3))

	# Controles tactiles
	if show_touch:
		var bs := _buttons()
		for k in bs:
			var b: Array = bs[k]
			var bc: Vector2 = b[0]
			var r: float = b[1]
			var on: bool = k == "fire" and fire_held
			draw_circle(bc, r, Color(1.0, 0.3, 0.2, 0.35) if on else Color(1.0, 1.0, 1.0, 0.12))
			draw_arc(bc, r, 0.0, TAU, 40, Color(1.0, 1.0, 1.0, 0.5), 2.0)
			draw_string(font, bc + Vector2(-r, 6.0), str(b[2]), HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 16, Color(1.0, 1.0, 1.0, 0.85))
		if joy_id == -1:
			var jc := Vector2(180.0, h - 190.0)
			draw_circle(jc, 90.0, Color(1.0, 1.0, 1.0, 0.07))
			draw_arc(jc, 90.0, 0.0, TAU, 40, Color(1.0, 1.0, 1.0, 0.35), 2.0)
			draw_circle(jc, 36.0, Color(1.0, 1.0, 1.0, 0.2))
			draw_string(font, jc + Vector2(-90.0, 120.0), "MOVER", HORIZONTAL_ALIGNMENT_CENTER, 180.0, 16, Color(1.0, 1.0, 1.0, 0.6))
		else:
			draw_circle(joy_origin, 90.0, Color(1.0, 1.0, 1.0, 0.1))
			draw_arc(joy_origin, 90.0, 0.0, TAU, 40, Color(1.0, 1.0, 1.0, 0.4), 2.0)
			draw_circle(joy_origin + move_vec * 90.0, 36.0, Color(1.0, 1.0, 1.0, 0.35))
