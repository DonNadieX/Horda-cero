extends Node3D
# HORDA CERO - prototipo de shooter cooperativo de zombis.
# Todo el nivel, los personajes y los sonidos se generan por codigo (sin assets externos).

const PlayerScript = preload("res://scripts/player.gd")
const ZombieScript = preload("res://scripts/zombie.gd")
const BotScript = preload("res://scripts/bot.gd")
const HudScript = preload("res://scripts/hud.gd")
const SfxScript = preload("res://scripts/sfx.gd")

const STREET_LEN := 240.0
const HALF_W := 8.0
const MAX_ZOMBIES := 32

var world: Node3D
var player
var bots: Array = []
var survivors: Array = []
var hud
var sfx
var playing := false
var finished := false
var kills := 0
var headshots := 0
var time_played := 0.0
var horde_t := 28.0
var special_t := 20.0
var next_wander_z := -24.0
var finale_done := false
var pending_spawns := 0
var spawn_tick := 0.0
var blocked: Array[Rect2] = []
var flicker_lights: Array = []
var rng := RandomNumberGenerator.new()
var _meshes := {}
var _mats := {}


func _ready() -> void:
	rng.randomize()
	world = Node3D.new()
	add_child(world)
	_environment()
	sfx = SfxScript.new()
	add_child(sfx)
	_build_level()

	player = PlayerScript.new()
	player.setup(self)
	player.position = Vector3(0.0, 0.1, 5.0)
	add_child(player)

	var b1 = BotScript.new()
	b1.setup(self, player, "Vega", Color(0.2, 0.4, 0.6), Vector3(-1.2, 0.0, 1.8))
	b1.position = Vector3(-1.6, 0.1, 7.0)
	add_child(b1)
	var b2 = BotScript.new()
	b2.setup(self, player, "Rolo", Color(0.6, 0.45, 0.15), Vector3(1.2, 0.0, 2.5))
	b2.position = Vector3(1.6, 0.1, 7.6)
	add_child(b2)
	bots = [b1, b2]
	survivors = [player, b1, b2]

	var layer := CanvasLayer.new()
	add_child(layer)
	hud = HudScript.new()
	layer.add_child(hud)
	hud.setup(self, player)
	player.hud = hud
	sfx.listener = player


func start() -> void:
	playing = true
	if not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	hud.msg("Llega al refugio al final de la calle", 4.0, Color(1.0, 0.85, 0.6))


func game_over(win: bool) -> void:
	if finished:
		return
	finished = true
	playing = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	hud.show_end(win, kills, headshots, time_played)


# ---------------------------------------------------------------- utilidades

func box_mesh(size: Vector3) -> BoxMesh:
	var key := "%.3f_%.3f_%.3f" % [size.x, size.y, size.z]
	if _meshes.has(key):
		return _meshes[key]
	var m := BoxMesh.new()
	m.size = size
	_meshes[key] = m
	return m


func mat(color: Color, unshaded := false) -> StandardMaterial3D:
	var key := color.to_html() + ("u" if unshaded else "")
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.9
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_mats[key] = m
	return m


func add_box(parent: Node, size: Vector3, pos: Vector3, color: Color, unshaded := false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = box_mesh(size)
	mi.material_override = mat(color, unshaded)
	mi.position = pos
	parent.add_child(mi)
	return mi


func add_solid(size: Vector3, pos: Vector3, color: Color, block := true) -> StaticBody3D:
	var sb := StaticBody3D.new()
	sb.collision_layer = 1
	sb.collision_mask = 0
	sb.position = pos
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	sb.add_child(cs)
	add_box(sb, size, Vector3.ZERO, color)
	world.add_child(sb)
	if block:
		blocked.append(Rect2(pos.x - size.x * 0.5 - 0.7, pos.z - size.z * 0.5 - 0.7, size.x + 1.4, size.z + 1.4))
	return sb


# ---------------------------------------------------------------- nivel

func _environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.03, 0.04, 0.06)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.4, 0.45, 0.6)
	env.ambient_light_energy = 0.55
	env.fog_enabled = true
	env.fog_light_color = Color(0.03, 0.04, 0.06)
	env.fog_density = 0.045
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-55.0, 30.0, 0.0)
	moon.light_color = Color(0.6, 0.7, 1.0)
	moon.light_energy = 0.3
	moon.shadow_enabled = false
	add_child(moon)


func _build_level() -> void:
	# Suelo (una sola colision, visual por tramos)
	var g := StaticBody3D.new()
	g.collision_layer = 1
	g.collision_mask = 0
	g.position = Vector3(0.0, -0.5, -STREET_LEN * 0.5)
	var gcs := CollisionShape3D.new()
	var gsh := BoxShape3D.new()
	gsh.size = Vector3(60.0, 1.0, STREET_LEN + 80.0)
	gcs.shape = gsh
	g.add_child(gcs)
	world.add_child(g)
	var z := 20.0
	while z > -STREET_LEN - 20.0:
		add_box(world, Vector3(HALF_W * 2.0, 0.1, 20.0), Vector3(0.0, -0.05, z - 10.0), Color(0.13, 0.13, 0.14))
		z -= 20.0
	z = -4.0
	while z > -STREET_LEN + 4.0:
		add_box(world, Vector3(0.16, 0.02, 2.6), Vector3(0.0, 0.011, z), Color(0.7, 0.6, 0.2))
		z -= 7.0

	# Edificios a los lados
	var palette := [Color(0.3, 0.2, 0.17), Color(0.25, 0.25, 0.27), Color(0.33, 0.3, 0.25), Color(0.2, 0.22, 0.26), Color(0.28, 0.18, 0.2)]
	for sx in [-1.0, 1.0]:
		var s: float = sx
		var bz := 14.0
		while bz > -STREET_LEN - 14.0:
			var bw := rng.randf_range(8.0, 15.0)
			var bh := rng.randf_range(6.0, 16.0)
			var bc: Color = palette[rng.randi() % palette.size()]
			add_solid(Vector3(10.0, bh, bw), Vector3(s * (HALF_W + 5.0), bh * 0.5, bz - bw * 0.5), bc, false)
			for k in rng.randi_range(0, 2):
				add_box(world, Vector3(0.1, 1.2, 1.0), Vector3(s * (HALF_W - 0.02), rng.randf_range(2.5, bh - 1.5), bz - rng.randf_range(1.0, bw - 1.0)), Color(0.85, 0.7, 0.35), true)
			bz -= bw

	_build_refuge(0.0, 1.0, Color(1.0, 0.75, 0.45))
	_build_refuge(-STREET_LEN, -1.0, Color(0.5, 1.0, 0.6))

	# Obstaculos en la calle
	var oz := -14.0
	var side := 1.0
	while oz > -STREET_LEN + 14.0:
		var r := rng.randf()
		var near_item := false
		for iz in [-60.0, -95.0, -130.0, -170.0, -200.0]:
			if absf(oz - float(iz)) < 4.5:
				near_item = true
		if near_item:
			pass
		elif r < 0.45:
			_car(Vector3(rng.randf_range(-5.5, 5.5), 0.0, oz), rng.randf() < 0.3)
		elif r < 0.65:
			var bus := add_solid(Vector3(9.0, 3.0, 2.6), Vector3(side * 3.5, 1.5, oz), Color(0.5, 0.42, 0.15))
			add_box(bus, Vector3(8.6, 0.8, 2.64), Vector3(0.0, 0.6, 0.0), Color(0.08, 0.1, 0.13))
			side = -side
		elif r < 0.85:
			add_solid(Vector3(7.0, 1.0, 0.6), Vector3(side * 4.5, 0.5, oz), Color(0.45, 0.45, 0.45))
			side = -side
		else:
			add_solid(Vector3(2.2, 1.5, 1.3), Vector3(side * 6.6, 0.75, oz), Color(0.12, 0.3, 0.18))
		oz -= rng.randf_range(9.0, 14.0)

	# Farolas (algunas parpadean)
	var lz := -22.0
	var ls := 1.0
	var li := 0
	while lz > -STREET_LEN + 10.0:
		add_box(world, Vector3(0.15, 5.0, 0.15), Vector3(ls * 7.6, 2.5, lz), Color(0.1, 0.1, 0.1))
		add_box(world, Vector3(1.2, 0.12, 0.3), Vector3(ls * 7.0, 5.0, lz), Color(1.0, 0.85, 0.6), true)
		var ol := OmniLight3D.new()
		ol.position = Vector3(ls * 6.6, 4.7, lz)
		ol.omni_range = 16.0
		ol.light_energy = 2.2
		ol.light_color = Color(1.0, 0.8, 0.55)
		ol.shadow_enabled = false
		world.add_child(ol)
		if li % 3 == 1:
			flicker_lights.append(ol)
		li += 1
		ls = -ls
		lz -= 40.0

	# Objetos: municion y botiquines
	_pickup("medkit", Vector3(3.0, 0.0, 6.0))
	_pickup("ammo", Vector3(-4.5, 0.0, -60.0))
	_pickup("medkit", Vector3(5.0, 0.0, -95.0))
	_pickup("ammo", Vector3(4.5, 0.0, -130.0))
	_pickup("medkit", Vector3(-5.0, 0.0, -170.0))
	_pickup("ammo", Vector3(-4.0, 0.0, -200.0))


func _build_refuge(zf: float, dir: float, light_color: Color) -> void:
	var wall := Color(0.32, 0.3, 0.28)
	var frame := Color(0.75, 0.15, 0.1)
	# Fachada con puerta de 4 m
	add_solid(Vector3(6.0, 5.0, 0.5), Vector3(-5.0, 2.5, zf), wall, false)
	add_solid(Vector3(6.0, 5.0, 0.5), Vector3(5.0, 2.5, zf), wall, false)
	add_solid(Vector3(4.0, 2.2, 0.5), Vector3(0.0, 3.9, zf), frame, false)
	add_box(world, Vector3(0.25, 2.8, 0.6), Vector3(-2.1, 1.4, zf), frame)
	add_box(world, Vector3(0.25, 2.8, 0.6), Vector3(2.1, 1.4, zf), frame)
	# Fondo y techo
	add_solid(Vector3(36.0, 12.0, 1.0), Vector3(0.0, 6.0, zf + dir * 14.5), wall, false)
	add_solid(Vector3(HALF_W * 2.0, 0.3, 14.0), Vector3(0.0, 5.15, zf + dir * 7.0), Color(0.2, 0.2, 0.2), false)
	add_solid(Vector3(2.4, 0.9, 1.0), Vector3(-5.5, 0.45, zf + dir * 9.0), Color(0.35, 0.25, 0.15), false)
	var ol := OmniLight3D.new()
	ol.position = Vector3(0.0, 3.8, zf + dir * 6.0)
	ol.omni_range = 13.0
	ol.light_energy = 2.0
	ol.light_color = light_color
	ol.shadow_enabled = false
	world.add_child(ol)
	add_box(world, Vector3(3.0, 0.5, 0.1), Vector3(0.0, 4.3, zf - dir * 0.3), light_color, true)


func _car(pos: Vector3, cross: bool) -> void:
	var colors := [Color(0.4, 0.1, 0.1), Color(0.12, 0.2, 0.35), Color(0.35, 0.35, 0.37), Color(0.1, 0.1, 0.11), Color(0.5, 0.5, 0.45)]
	var c: Color = colors[rng.randi() % colors.size()]
	var size := Vector3(1.9, 1.0, 4.3)
	var cabin := Vector3(1.7, 0.6, 2.1)
	if cross:
		size = Vector3(4.3, 1.0, 1.9)
		cabin = Vector3(2.1, 0.6, 1.7)
	var sb := add_solid(size, pos + Vector3(0.0, 0.6, 0.0), c)
	add_box(sb, cabin, Vector3(0.0, 0.8, 0.0), Color(0.07, 0.09, 0.12))


func _pickup(kind: String, pos: Vector3) -> void:
	var a := Area3D.new()
	a.collision_layer = 0
	a.collision_mask = 4
	a.position = pos
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 1.4
	cs.shape = sh
	cs.position.y = 0.8
	a.add_child(cs)
	add_box(a, Vector3(0.9, 0.5, 0.9), Vector3(0.0, 0.25, 0.0), Color(0.3, 0.22, 0.14))
	if kind == "ammo":
		add_box(a, Vector3(0.6, 0.35, 0.4), Vector3(0.0, 0.68, 0.0), Color(0.85, 0.75, 0.2), true)
	else:
		add_box(a, Vector3(0.5, 0.4, 0.25), Vector3(0.0, 0.7, 0.0), Color(0.85, 0.1, 0.1), true)
		add_box(a, Vector3(0.3, 0.08, 0.27), Vector3(0.0, 0.7, 0.0), Color.WHITE, true)
		add_box(a, Vector3(0.08, 0.3, 0.27), Vector3(0.0, 0.7, 0.0), Color.WHITE, true)
	a.body_entered.connect(_on_pickup.bind(a, kind))
	world.add_child(a)


func _on_pickup(body: Node3D, a: Area3D, kind: String) -> void:
	if body != player or not playing:
		return
	if kind == "ammo":
		player.refill()
		hud.msg("Munición recargada", 2.0, Color(1.0, 0.9, 0.4))
	else:
		if player.medkits >= 2:
			hud.msg("Ya llevas 2 botiquines", 2.0)
			return
		player.medkits += 1
		hud.msg("Botiquín recogido", 2.0, Color(0.5, 1.0, 0.5))
	sfx.play("pickup", 0.0)
	a.queue_free()


# ---------------------------------------------------------------- director

func zombie_count() -> int:
	return get_tree().get_nodes_in_group("zombies").size()


func nearest_survivor(pos: Vector3):
	var best = null
	var bd := 1.0e12
	for s in survivors:
		if s.down:
			continue
		var d: float = pos.distance_squared_to(s.global_position)
		if d < bd:
			bd = d
			best = s
	return best


func any_bot_alive() -> bool:
	for b in bots:
		if not b.down:
			return true
	return false


func _free_spot(z: float) -> Vector3:
	for i in 8:
		var p := Vector2(rng.randf_range(-HALF_W + 1.0, HALF_W - 1.0), z + rng.randf_range(-2.5, 2.5))
		var ok := true
		for r in blocked:
			if r.has_point(p):
				ok = false
				break
		if ok:
			return Vector3(p.x, 0.1, p.y)
	return Vector3(0.0, 0.1, z)


func spawn_zombie(kind: String, z: float, aggro: bool) -> void:
	z = clampf(z, -STREET_LEN + 4.0, -4.0)
	var zb = ZombieScript.new()
	zb.setup(self, kind, _free_spot(z), aggro)
	world.add_child(zb)


func spawn_horde(n: int, text := "¡SE ACERCA LA HORDA!") -> void:
	pending_spawns = mini(pending_spawns + n, 30)
	hud.msg(text, 3.5, Color(1.0, 0.3, 0.2))
	sfx.play("horde", 2.0)


func _has_kind(k: String) -> bool:
	for z in get_tree().get_nodes_in_group("zombies"):
		if z.kind == k:
			return true
	return false


func _spawn_special() -> void:
	var pz: float = player.global_position.z
	var r := rng.randf()
	var k := "acechador"
	if r > 0.78 and pz < -70.0 and not _has_kind("bruto"):
		k = "bruto"
	elif r > 0.42:
		k = "hinchado"
	var z: float = pz - rng.randf_range(30.0, 38.0)
	if z < -STREET_LEN + 5.0:
		z = pz + 32.0
	spawn_zombie(k, z, true)
	if k == "bruto":
		hud.msg("¡UN BRUTO! No dejes que te alcance", 3.5, Color(1.0, 0.3, 0.2))
		sfx.play("roar", 4.0)


func _process(delta: float) -> void:
	for l in flicker_lights:
		l.light_energy = 2.2 if randf() > 0.07 else 0.2
	if not playing:
		return
	time_played += delta
	var pz: float = player.global_position.z

	# Victoria: entrar al refugio final
	if pz < -STREET_LEN - 1.5 and not player.down:
		game_over(true)
		return
	# Derrota: jugador caido y nadie puede reanimarlo
	if player.down and not any_bot_alive():
		player.dead = true
		game_over(false)
		return

	# Infectados errantes por delante
	while next_wander_z > pz - 60.0 and next_wander_z > -STREET_LEN + 6.0 and zombie_count() < MAX_ZOMBIES - 6:
		for i in rng.randi_range(2, 4):
			spawn_zombie("comun", next_wander_z, false)
		next_wander_z -= rng.randf_range(8.0, 14.0)

	# Hordas periodicas
	horde_t -= delta
	if horde_t <= 0.0:
		horde_t = rng.randf_range(38.0, 55.0)
		spawn_horde(12 + int(-pz / 40.0))
	special_t -= delta
	if special_t <= 0.0:
		special_t = rng.randf_range(22.0, 34.0)
		if pz < -15.0:
			_spawn_special()

	# Final: horda al acercarse al refugio
	if not finale_done and pz < -STREET_LEN + 40.0:
		finale_done = true
		spawn_horde(20, "¡EL REFUGIO ESTÁ CERCA! ¡CORRE!")

	# Las hordas salen poco a poco, fuera de la vista
	spawn_tick -= delta
	if pending_spawns > 0 and spawn_tick <= 0.0:
		spawn_tick = 0.35
		for i in mini(3, pending_spawns):
			if zombie_count() >= MAX_ZOMBIES:
				break
			var z: float = pz + rng.randf_range(26.0, 34.0)
			if rng.randf() < 0.45 or z > -5.0:
				z = pz - rng.randf_range(28.0, 36.0)
			if z < -STREET_LEN + 5.0:
				z = pz + rng.randf_range(26.0, 34.0)
			spawn_zombie("comun", z, true)
			pending_spawns -= 1


func alert(pos: Vector3, radius: float) -> void:
	var r2 := radius * radius
	for z in get_tree().get_nodes_in_group("zombies"):
		if not z.aggro and pos.distance_squared_to(z.global_position) < r2:
			z.aggro = true


func on_zombie_killed(_z, headshot: bool) -> void:
	kills += 1
	if headshot:
		headshots += 1


func bloat_explode(pos: Vector3) -> void:
	sfx.play("explode", 4.0, pos)
	fx_burst(pos + Vector3(0.0, 1.0, 0.0), Color(0.5, 0.7, 0.15), 30, 0.25)
	var hit_any := false
	for s in survivors:
		if s.down:
			continue
		var d: float = pos.distance_to(s.global_position)
		if d < 5.0:
			s.take_damage(8.0)
			hit_any = true
			if s == player:
				player.bile()
	if hit_any and playing:
		spawn_horde(10, "¡El Hinchado atrajo a la horda!")


# ---------------------------------------------------------------- efectos

func fx_tracer(from: Vector3, to: Vector3) -> void:
	var d := to - from
	var length := d.length()
	if length < 1.0:
		return
	var mi := MeshInstance3D.new()
	mi.mesh = box_mesh(Vector3(1.0, 1.0, 1.0))
	mi.material_override = mat(Color(1.0, 0.9, 0.55), true)
	add_child(mi)
	var up := Vector3.UP
	if absf(d.y / length) > 0.98:
		up = Vector3.RIGHT
	mi.global_transform = Transform3D(Basis.looking_at(d / length, up), from + d * 0.5)
	mi.scale = Vector3(0.015, 0.015, length)
	get_tree().create_timer(0.05).timeout.connect(mi.queue_free)


func fx_burst(pos: Vector3, color: Color, amount := 8, psize := 0.07) -> void:
	var p := CPUParticles3D.new()
	p.mesh = box_mesh(Vector3(psize, psize, psize))
	p.material_override = mat(color, true)
	p.amount = amount
	p.lifetime = 0.45
	p.one_shot = true
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = 1.5
	p.initial_velocity_max = 4.0
	p.position = pos
	add_child(p)
	p.emitting = true
	get_tree().create_timer(0.7).timeout.connect(p.queue_free)
