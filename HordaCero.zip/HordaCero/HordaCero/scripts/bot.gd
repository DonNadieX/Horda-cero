extends CharacterBody3D
# Companero controlado por IA: sigue al jugador, dispara a los infectados y lo reanima.

var game
var player
var bname := "Bot"
var kind := "bot"
var hp := 100.0
var down := false
var offset := Vector3.ZERO
var fire_cd := 0.0
var scan_t := 0.0
var tgt = null
var revive_p := 0.0
var stuck_t := 0.0
var last_hit := 99.0
var anim_t := 0.0
var vis: Node3D
var leg_l: Node3D
var leg_r: Node3D
var gun_tip: Node3D


func setup(g, p, n: String, color: Color, off: Vector3) -> void:
	game = g
	player = p
	bname = n
	offset = off
	collision_layer = 8
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	vis = Node3D.new()
	add_child(vis)
	var skin := Color(0.75, 0.6, 0.5)
	game.add_box(vis, Vector3(0.55, 0.65, 0.3), Vector3(0.0, 1.18, 0.0), color)
	game.add_box(vis, Vector3(0.3, 0.3, 0.3), Vector3(0.0, 1.68, 0.0), skin)
	game.add_box(vis, Vector3(0.32, 0.1, 0.32), Vector3(0.0, 1.86, 0.0), color.darkened(0.4))
	game.add_box(vis, Vector3(0.6, 0.14, 0.5), Vector3(0.0, 1.32, -0.3), skin)
	game.add_box(vis, Vector3(0.07, 0.1, 0.7), Vector3(0.12, 1.36, -0.6), Color(0.12, 0.12, 0.13))
	gun_tip = Node3D.new()
	gun_tip.position = Vector3(0.12, 1.36, -1.0)
	vis.add_child(gun_tip)
	leg_l = Node3D.new()
	leg_l.position = Vector3(-0.14, 0.85, 0.0)
	vis.add_child(leg_l)
	game.add_box(leg_l, Vector3(0.22, 0.85, 0.22), Vector3(0.0, -0.425, 0.0), Color(0.18, 0.2, 0.28))
	leg_r = Node3D.new()
	leg_r.position = Vector3(0.14, 0.85, 0.0)
	vis.add_child(leg_r)
	game.add_box(leg_r, Vector3(0.22, 0.85, 0.22), Vector3(0.0, -0.425, 0.0), Color(0.18, 0.2, 0.28))


func take_damage(amount: float, _from = null) -> void:
	if down or not game.playing:
		return
	hp -= amount
	last_hit = 0.0
	if hp <= 0.0:
		hp = 0.0
		down = true
		revive_p = 0.0
		vis.rotation.x = 1.5
		vis.position.y = 0.2
		game.hud.msg("%s ha caído. ¡Acércate para reanimar!" % bname, 4.0, Color(1.0, 0.7, 0.2))


func _revive() -> void:
	down = false
	hp = 50.0
	revive_p = 0.0
	vis.rotation.x = 0.0
	vis.position.y = 0.0
	game.hud.msg("%s está de pie otra vez" % bname, 2.5, Color(0.5, 1.0, 0.5))


func _teleport() -> void:
	stuck_t = 0.0
	global_position = player.global_position + player.global_transform.basis * Vector3(offset.x * 0.6, 0.2, 1.6)


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= 20.0 * delta
	if not game.playing:
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		return
	if down:
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		if not player.down and global_position.distance_to(player.global_position) < 2.4:
			revive_p += delta / 3.0
			if revive_p >= 1.0:
				_revive()
		else:
			revive_p = maxf(0.0, revive_p - delta)
		return

	last_hit += delta
	if last_hit > 6.0:
		hp = minf(100.0, hp + 2.0 * delta)

	var goal: Vector3 = player.global_position
	if not player.down:
		goal = player.global_position + player.global_transform.basis * offset
	var to := goal - global_position
	to.y = 0.0
	var d := to.length()
	if d > 30.0:
		_teleport()
		return
	var stop_d := 1.3 if player.down else 1.0
	var mv := Vector3.ZERO
	if d > stop_d:
		mv = to / d * (7.2 if d > 6.0 else 5.0)
	velocity.x = mv.x
	velocity.z = mv.z
	move_and_slide()
	if d > 4.0 and get_real_velocity().length() < 1.0:
		stuck_t += delta
		if stuck_t > 1.5:
			_teleport()
	else:
		stuck_t = 0.0

	# Reanimar al jugador caido
	if player.down and not player.dead and d < 2.2:
		player.revive_p += delta / 3.0
		if player.revive_p >= 1.0:
			player.revive()

	# Combate
	scan_t -= delta
	fire_cd -= delta
	if scan_t <= 0.0:
		scan_t = 0.25
		tgt = _find_target()
	var face := mv
	if tgt != null and is_instance_valid(tgt) and not tgt.dead:
		var tv: Vector3 = tgt.global_position - global_position
		tv.y = 0.0
		face = tv
		if fire_cd <= 0.0:
			fire_cd = 0.28
			var dirn := tv.normalized()
			var end: Vector3 = tgt.global_position + Vector3(0.0, 1.1, 0.0)
			if randf() < 0.8:
				tgt.hurt(13.0, randf() < 0.15, dirn)
				game.fx_burst(end, Color(0.5, 0.05, 0.05))
			game.fx_tracer(gun_tip.global_position, end)
			game.sfx.play("rifle", -9.0, global_position)
	if face.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(-face.x, -face.z), minf(1.0, 12.0 * delta))

	var moving := mv.length() > 0.5
	if moving:
		anim_t += delta * 12.0
	var sw := sin(anim_t) * 0.6 if moving else 0.0
	leg_l.rotation.x = sw
	leg_r.rotation.x = -sw


# OPTIMIZACIÓN: Busca el más cercano por distancia y solo hace 1 raycast
func _find_target():
	var best = null
	var bd := 20.0 * 20.0
	var from := global_position + Vector3(0.0, 1.4, 0.0)
	
	# 1. Encontrar el zombi más cercano
	for z in get_tree().get_nodes_in_group("zombies"):
		if z.dead: continue
		var d: float = global_position.distance_squared_to(z.global_position)
		if d < bd:
			bd = d
			best = z
			
	# 2. Si hay uno cercano, comprobar si hay línea de visión
	if best != null:
		var space := get_world_3d().direct_space_state
		var q := PhysicsRayQueryParameters3D.create(from, best.global_position + Vector3(0.0, 1.0, 0.0), 1)
		if not space.intersect_ray(q).is_empty():
			return null # Hay una pared, no disparar
	return best