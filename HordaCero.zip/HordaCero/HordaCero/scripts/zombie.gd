extends CharacterBody3D
# Infectado. Tipos: comun, acechador (salta), hinchado (explota y atrae horda), bruto (tanque).

var game
var kind := "comun"
var hp := 30.0
var max_hp := 30.0
var speed := 4.5
var damage := 5.0
var attack_rate := 0.9
var attack_range := 1.5
var attack_cd := 0.3
var attack_anim := 0.0
var target = null
var retarget_t := 0.0
var dead := false
var aggro := false
var anim_t := 0.0
var stagger_t := 0.0
var knock := Vector3.ZERO
var leap_cd := 2.0
var leaping := false
var stuck_t := 0.0
var side_t := 0.0
var side := 1.0
var growl_t := 2.0
var head_y := 1.5
var lane := Vector3.ZERO
var vis: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var col: CollisionShape3D

const SKINS := [Color(0.45, 0.52, 0.42), Color(0.55, 0.55, 0.48), Color(0.4, 0.45, 0.45)]
const SHIRTS := [Color(0.35, 0.2, 0.2), Color(0.2, 0.3, 0.38), Color(0.3, 0.32, 0.22), Color(0.4, 0.38, 0.35), Color(0.25, 0.2, 0.32), Color(0.5, 0.45, 0.3)]


func setup(g, k: String, pos: Vector3, start_aggro: bool) -> void:
	game = g
	kind = k
	aggro = start_aggro
	position = pos
	rotation.y = randf() * TAU
	collision_layer = 2
	collision_mask = 1
	add_to_group("zombies")
	lane = Vector3(randf_range(-0.9, 0.9), 0.0, randf_range(-0.9, 0.9))
	growl_t = randf_range(0.5, 6.0)

	var skin: Color = SKINS[randi() % SKINS.size()]
	var shirt: Color = SHIRTS[randi() % SHIRTS.size()]
	var pants := Color(0.15, 0.17, 0.25)
	var eyes := Color(1.0, 0.8, 0.3)
	var vscale := Vector3.ONE
	var radius := 0.35
	var height := 1.8
	match kind:
		"comun":
			hp = 30.0
			speed = randf_range(3.6, 5.0)
			damage = 5.0
		"acechador":
			hp = 90.0
			speed = 6.2
			damage = 10.0
			shirt = Color(0.08, 0.09, 0.14)
			pants = Color(0.06, 0.06, 0.08)
			skin = Color(0.5, 0.5, 0.55)
			eyes = Color(1.0, 0.2, 0.2)
		"hinchado":
			hp = 50.0
			speed = 2.8
			damage = 4.0
			shirt = Color(0.45, 0.5, 0.25)
			skin = Color(0.55, 0.6, 0.35)
			eyes = Color(0.6, 1.0, 0.3)
			vscale = Vector3(1.7, 1.05, 1.7)
			radius = 0.55
		"bruto":
			hp = 900.0
			speed = 5.4
			damage = 24.0
			attack_range = 2.5
			attack_rate = 1.3
			shirt = Color(0.45, 0.22, 0.2)
			skin = Color(0.5, 0.3, 0.28)
			pants = Color(0.2, 0.15, 0.12)
			eyes = Color(1.0, 0.3, 0.1)
			vscale = Vector3(2.0, 1.7, 1.9)
			radius = 0.75
			height = 3.0
	max_hp = hp
	head_y = 1.5 * vscale.y

	col = CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = radius
	cap.height = height
	col.shape = cap
	col.position.y = height * 0.5
	add_child(col)

	vis = Node3D.new()
	vis.scale = vscale
	add_child(vis)
	game.add_box(vis, Vector3(0.55, 0.65, 0.3), Vector3(0.0, 1.18, 0.0), shirt)
	game.add_box(vis, Vector3(0.3, 0.3, 0.3), Vector3(0.0, 1.68, 0.0), skin)
	game.add_box(vis, Vector3(0.2, 0.04, 0.02), Vector3(0.0, 1.72, -0.155), eyes, true)
	leg_l = _limb(Vector3(-0.14, 0.85, 0.0), Vector3(0.22, 0.85, 0.22), pants)
	leg_r = _limb(Vector3(0.14, 0.85, 0.0), Vector3(0.22, 0.85, 0.22), pants)
	arm_l = _limb(Vector3(-0.36, 1.45, 0.0), Vector3(0.16, 0.7, 0.16), skin)
	arm_r = _limb(Vector3(0.36, 1.45, 0.0), Vector3(0.16, 0.7, 0.16), skin)


func _limb(pivot: Vector3, size: Vector3, color: Color) -> Node3D:
	var n := Node3D.new()
	n.position = pivot
	vis.add_child(n)
	game.add_box(n, size, Vector3(0.0, -size.y * 0.5, 0.0), color)
	return n


func _physics_process(delta: float) -> void:
	if dead:
		return
		
	# OPTIMIZACIÓN: Culling por distancia (si está a más de 50m, no procesar física)
	if global_position.distance_squared_to(game.player.global_position) > 2500:
		return
		
	if not is_on_floor():
		velocity.y -= 20.0 * delta
	elif leaping and velocity.y <= 0.0:
		leaping = false

	if stagger_t > 0.0:
		stagger_t -= delta
		velocity.x = knock.x
		velocity.z = knock.z
		knock = knock.move_toward(Vector3.ZERO, 14.0 * delta)
		move_and_slide()
		return

	retarget_t -= delta
	if retarget_t <= 0.0 or target == null or target.down:
		target = game.nearest_survivor(global_position)
		retarget_t = 0.8 + randf() * 0.4
	if target == null or not game.playing:
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		return

	var to: Vector3 = target.global_position - global_position
	to.y = 0.0
	var dist := to.length()
	if not aggro:
		if dist < 20.0:
			aggro = true
		else:
			velocity.x = 0.0
			velocity.z = 0.0
			move_and_slide()
			return

	var dir := to / maxf(dist, 0.01)
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, 10.0 * delta))
	attack_cd -= delta
	leap_cd -= delta

	if leaping:
		if dist < 1.7:
			target.take_damage(18.0, self)
			leaping = false
			attack_cd = attack_rate
		move_and_slide()
		return

	if kind == "acechador" and leap_cd <= 0.0 and dist > 5.0 and dist < 13.0 and is_on_floor():
		leap_cd = 5.0
		leaping = true
		velocity = dir * 15.0 + Vector3.UP * 6.0
		game.sfx.play("scream", 0.0, global_position)
		move_and_slide()
		return

	if kind == "hinchado" and dist < 2.2:
		hurt(9999.0, false, Vector3.ZERO)
		return

	if dist <= attack_range:
		velocity.x = 0.0
		velocity.z = 0.0
		if attack_cd <= 0.0:
			attack_cd = attack_rate
			attack_anim = 0.3
			target.take_damage(damage, self)
			game.sfx.play("hit", -4.0, global_position)
	else:
		var mdir := dir
		if dist > 3.0:
			var lt: Vector3 = (target.global_position + lane) - global_position
			lt.y = 0.0
			mdir = lt.normalized()
		if side_t > 0.0:
			side_t -= delta
			mdir = (mdir * 0.3 + Vector3(side, 0.0, 0.0)).normalized()
		velocity.x = mdir.x * speed
		velocity.z = mdir.z * speed
	move_and_slide()

	# Si se atora contra un obstaculo, lo rodea de lado.
	if dist > attack_range and side_t <= 0.0:
		var rv := get_real_velocity()
		if Vector2(rv.x, rv.z).length() < speed * 0.3:
			stuck_t += delta
			if stuck_t > 0.35:
				stuck_t = 0.0
				side_t = 1.1
				if absf(global_position.x) > 2.0:
					side = -signf(global_position.x)
				else:
					side = 1.0 if randf() < 0.5 else -1.0
		else:
			stuck_t = 0.0


func _process(delta: float) -> void:
	if dead:
		return
	if aggro:
		growl_t -= delta
		if growl_t <= 0.0:
			growl_t = randf_range(4.0, 10.0)
			if kind == "bruto":
				game.sfx.play("roar", -2.0, global_position)
			else:
				game.sfx.play("growl", -8.0, global_position, 1.5 if kind == "acechador" else 1.0)
	var moving := Vector2(velocity.x, velocity.z).length() > 0.5
	if moving:
		anim_t += delta * speed * 2.2
	var sw := sin(anim_t) * 0.7 if moving else 0.0
	leg_l.rotation.x = sw
	leg_r.rotation.x = -sw
	attack_anim = maxf(0.0, attack_anim - delta)
	var raise := 1.35 if aggro else 0.15
	var hit := sin(attack_anim / 0.3 * PI) * 0.9
	arm_l.rotation.x = raise + sw * 0.25 + hit
	arm_r.rotation.x = raise - sw * 0.25 + hit
	vis.rotation.x = -0.12 if moving else 0.0


func hurt(amount: float, headshot: bool, push: Vector3) -> void:
	if dead:
		return
	aggro = true
	hp -= amount
	if hp <= 0.0:
		_die(headshot)
	elif kind == "comun" and push != Vector3.ZERO:
		stagger_t = 0.12
		knock = Vector3(push.x, 0.0, push.z) * 2.0


func shove(dir: Vector3) -> void:
	if dead or kind == "bruto":
		return
	aggro = true
	stagger_t = 0.8
	knock = dir * 8.0
	leaping = false
	hurt(5.0, false, Vector3.ZERO)


func _die(headshot: bool) -> void:
	dead = true
	remove_from_group("zombies")
	collision_layer = 0
	col.set_deferred("disabled", true)
	game.on_zombie_killed(self, headshot)
	
	# NUEVO: Hit-Stop (Micro-pausa) para dar sensación de impacto
	if headshot or kind == "bruto":
		Engine.time_scale = 0.1
		await get_tree().create_timer(0.05).timeout
		Engine.time_scale = 1.0
		
	if kind == "hinchado":
		game.bloat_explode(global_position)
		queue_free()
		return
	var tw := create_tween()
	tw.tween_property(vis, "rotation:x", 1.5, 0.35)
	tw.tween_interval(2.5)
	tw.tween_property(self, "position:y", position.y - 1.2, 1.0)
	tw.tween_callback(queue_free)