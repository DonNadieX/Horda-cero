extends CharacterBody3D
# Jugador en primera persona: movimiento, armas, empujon, botiquin.

const GUN_POS := Vector3(0.22, -0.2, -0.35)

var game
var hud
var cam: Camera3D
var gun: Node3D
var gun_models: Array = []
var muzzle: Node3D
var flash_light: OmniLight3D
var flash_mesh: MeshInstance3D
var hp := 100.0
var down := false
var dead := false
var downs := 0
var medkits := 1
var pitch := 0.0
var cur := 1
var fire_cd := 0.0
var reload_t := 0.0
var shove_cd := 0.0
var shove_anim := 0.0
var want_jump := false
var recoil := 0.0
var bob_t := 0.0
var bile_t := 0.0
var revive_p := 0.0
var knock := Vector3.ZERO
var mouse_fire := false
var mobile := false
var trauma := 0.0 # NUEVO: Para Screen Shake

var weapons: Array = [
	{"name": "Pistola", "mag": 15, "mag_size": 15, "reserve": -1, "reserve_max": -1, "dmg": 20.0, "rate": 0.2, "pellets": 1, "spread": 0.012, "reload": 1.2, "snd": "shot"},
	{"name": "Fusil", "mag": 30, "mag_size": 30, "reserve": 150, "reserve_max": 150, "dmg": 16.0, "rate": 0.095, "pellets": 1, "spread": 0.024, "reload": 1.9, "snd": "rifle"},
	{"name": "Escopeta", "mag": 8, "mag_size": 8, "reserve": 40, "reserve_max": 40, "dmg": 11.0, "rate": 0.7, "pellets": 9, "spread": 0.08, "reload": 2.3, "snd": "shotgun"},
]


func setup(g) -> void:
	game = g
	mobile = OS.has_feature("mobile")
	collision_layer = 4
	collision_mask = 3
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	cam = Camera3D.new()
	cam.position.y = 1.6
	cam.near = 0.05
	cam.far = 90.0
	cam.fov = 75.0
	cam.current = true
	add_child(cam)
	var spot := SpotLight3D.new()
	spot.spot_range = 30.0
	spot.spot_angle = 34.0
	spot.light_energy = 2.6
	spot.light_color = Color(1.0, 0.96, 0.85)
	spot.shadow_enabled = false
	cam.add_child(spot)
	_build_gun()


func _build_gun() -> void:
	gun = Node3D.new()
	gun.position = GUN_POS
	cam.add_child(gun)
	var dark := Color(0.13, 0.13, 0.15)
	var mid := Color(0.26, 0.26, 0.29)
	var wood := Color(0.36, 0.23, 0.12)
	var skin := Color(0.62, 0.48, 0.4)
	# Pistola
	var p := Node3D.new()
	gun.add_child(p)
	game.add_box(p, Vector3(0.05, 0.07, 0.24), Vector3(0.0, 0.02, -0.05), mid, true)
	game.add_box(p, Vector3(0.05, 0.13, 0.06), Vector3(0.0, -0.06, 0.04), dark, true)
	game.add_box(p, Vector3(0.09, 0.09, 0.3), Vector3(0.02, -0.1, 0.2), skin, true)
	# Fusil
	var r := Node3D.new()
	gun.add_child(r)
	game.add_box(r, Vector3(0.06, 0.09, 0.62), Vector3(0.0, 0.0, -0.15), dark, true)
	game.add_box(r, Vector3(0.03, 0.03, 0.2), Vector3(0.0, 0.01, -0.55), mid, true)
	game.add_box(r, Vector3(0.045, 0.18, 0.07), Vector3(0.0, -0.12, -0.12), mid, true)
	game.add_box(r, Vector3(0.05, 0.1, 0.22), Vector3(0.0, -0.03, 0.26), dark, true)
	game.add_box(r, Vector3(0.09, 0.09, 0.3), Vector3(0.03, -0.12, 0.2), skin, true)
	# Escopeta
	var s := Node3D.new()
	gun.add_child(s)
	game.add_box(s, Vector3(0.06, 0.07, 0.75), Vector3(0.0, 0.01, -0.2), mid, true)
	game.add_box(s, Vector3(0.075, 0.06, 0.22), Vector3(0.0, -0.045, -0.3), wood, true)
	game.add_box(s, Vector3(0.055, 0.11, 0.26), Vector3(0.0, -0.03, 0.28), wood, true)
	game.add_box(s, Vector3(0.09, 0.09, 0.3), Vector3(0.03, -0.12, 0.2), skin, true)
	gun_models = [p, r, s]
	muzzle = Node3D.new()
	muzzle.position = Vector3(0.0, 0.02, -0.68)
	gun.add_child(muzzle)
	flash_mesh = game.add_box(muzzle, Vector3(0.12, 0.12, 0.12), Vector3.ZERO, Color(1.0, 0.85, 0.4), true)
	flash_mesh.visible = false
	flash_light = OmniLight3D.new()
	flash_light.omni_range = 9.0
	flash_light.light_color = Color(1.0, 0.8, 0.5)
	flash_light.light_energy = 0.0
	muzzle.add_child(flash_light)
	_show_gun()


func _show_gun() -> void:
	for i in gun_models.size():
		gun_models[i].visible = i == cur


func add_look(d: Vector2) -> void:
	if down or not game.playing:
		return
	rotate_y(-d.x)
	pitch = clampf(pitch - d.y, -1.4, 1.4)
	cam.rotation.x = pitch


func _unhandled_input(event: InputEvent) -> void:
	if hud == null or not game.playing:
		return
	# Los toques generan eventos de raton "emulados": se ignoran aqui (los maneja el HUD).
	if event is InputEventMouse and event.device == InputEvent.DEVICE_ID_EMULATION:
		return
	if event is InputEventMouseMotion:
		if mobile or Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			add_look(event.relative * 0.0025)
	elif event is InputEventMouseButton:
		if event.pressed and not mobile and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		elif event.button_index == MOUSE_BUTTON_LEFT:
			mouse_fire = event.pressed
		elif event.pressed and event.button_index == MOUSE_BUTTON_RIGHT:
			shove()
		elif event.pressed and (event.button_index == MOUSE_BUTTON_WHEEL_DOWN or event.button_index == MOUSE_BUTTON_WHEEL_UP):
			next_weapon()
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.physical_keycode:
			KEY_ESCAPE:
				Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
				mouse_fire = false
			KEY_R:
				start_reload()
			KEY_Q:
				heal()
			KEY_E, KEY_V:
				shove()
			KEY_TAB:
				next_weapon()
			KEY_1:
				set_weapon(0)
			KEY_2:
				set_weapon(1)
			KEY_3:
				set_weapon(2)
	elif event is InputEventJoypadButton and event.pressed:
		match event.button_index:
			JOY_BUTTON_A:
				want_jump = true
			JOY_BUTTON_X:
				start_reload()
			JOY_BUTTON_B:
				shove()
			JOY_BUTTON_Y:
				next_weapon()
			JOY_BUTTON_LEFT_SHOULDER:
				heal()


func _axis(a: JoyAxis) -> float:
	var v := Input.get_joy_axis(0, a)
	return v if absf(v) > 0.2 else 0.0


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= 20.0 * delta
	var wish := Vector3.ZERO
	if game.playing and not down and hud != null:
		# Teclado + joystick tactil + mando, todo a la vez
		var iv := Vector2.ZERO
		iv.x = float(Input.is_physical_key_pressed(KEY_D)) - float(Input.is_physical_key_pressed(KEY_A))
		iv.y = float(Input.is_physical_key_pressed(KEY_S)) - float(Input.is_physical_key_pressed(KEY_W))
		var tv: Vector2 = hud.move_vec
		iv += tv
		iv += Vector2(_axis(JOY_AXIS_LEFT_X), _axis(JOY_AXIS_LEFT_Y))
		iv = iv.limit_length(1.0)
		wish = transform.basis * Vector3(iv.x, 0.0, iv.y)
		var jump: bool = want_jump or Input.is_physical_key_pressed(KEY_SPACE)
		if jump and is_on_floor():
			velocity.y = 6.5
		if wish.length() > 0.1 and is_on_floor():
			bob_t += delta * 10.0
		# Apuntar con flechas o palanca derecha
		var lk := Vector2.ZERO
		lk.x = float(Input.is_physical_key_pressed(KEY_RIGHT)) - float(Input.is_physical_key_pressed(KEY_LEFT))
		lk.y = float(Input.is_physical_key_pressed(KEY_DOWN)) - float(Input.is_physical_key_pressed(KEY_UP))
		lk += Vector2(_axis(JOY_AXIS_RIGHT_X), _axis(JOY_AXIS_RIGHT_Y))
		if lk != Vector2.ZERO:
			add_look(Vector2(lk.x * 2.4, lk.y * 1.5) * delta)
	want_jump = false
	var spd := 6.2 if hp >= 40.0 else 4.8
	velocity.x = move_toward(velocity.x, wish.x * spd + knock.x, 70.0 * delta)
	velocity.z = move_toward(velocity.z, wish.z * spd + knock.z, 70.0 * delta)
	knock = knock.move_toward(Vector3.ZERO, 30.0 * delta)
	move_and_slide()
	
	# NUEVO: FOV Dinámico
	var target_fov = 75.0
	if wish.length() > 0.1 and is_on_floor() and hp >= 40.0:
		target_fov = 82.0 # Se abre al correr
	if shove_anim > 0.0:
		target_fov = 85.0 # Efecto de empujón
	cam.fov = lerpf(cam.fov, target_fov, delta * 8.0)


func _process(delta: float) -> void:
	fire_cd -= delta
	shove_cd -= delta
	shove_anim = maxf(0.0, shove_anim - delta * 4.0)
	recoil = maxf(0.0, recoil - delta * 8.0)
	bile_t = maxf(0.0, bile_t - delta)
	flash_light.light_energy = maxf(0.0, flash_light.light_energy - delta * 40.0)
	if flash_light.light_energy < 1.0:
		flash_mesh.visible = false
	cam.position.y = lerpf(cam.position.y, 0.55 if down else 1.6, minf(1.0, delta * 6.0))
	cam.rotation.z = lerpf(cam.rotation.z, 0.5 if down else 0.0, minf(1.0, delta * 6.0))
	if down:
		revive_p = maxf(0.0, revive_p - delta * 0.08)
	
	# NUEVO: Screen Shake (Trauma)
	if trauma > 0.0:
		trauma = maxf(0.0, trauma - delta * 2.0)
		var shake = trauma * trauma
		cam.h_offset = randf_range(-1.0, 1.0) * shake * 0.15
		cam.v_offset = randf_range(-1.0, 1.0) * shake * 0.15
	else:
		cam.h_offset = 0.0
		cam.v_offset = 0.0

	if not game.playing or down or hud == null:
		return

	if reload_t > 0.0:
		reload_t -= delta
		if reload_t <= 0.0:
			_finish_reload()
	else:
		var firing: bool = hud.fire_held
		if mouse_fire or Input.is_physical_key_pressed(KEY_F) or Input.is_physical_key_pressed(KEY_CTRL):
			firing = true
		if Input.get_joy_axis(0, JOY_AXIS_TRIGGER_RIGHT) > 0.5 or Input.is_joy_button_pressed(0, JOY_BUTTON_RIGHT_SHOULDER):
			firing = true
		if firing and fire_cd <= 0.0:
			_shoot()

	var drop := 0.0
	if reload_t > 0.0:
		drop = 0.18
	var bob := sin(bob_t) * 0.008
	gun.position = gun.position.lerp(GUN_POS + Vector3(0.0, bob - drop, recoil * 0.07 - shove_anim * 0.25), minf(1.0, delta * 18.0))
	gun.rotation.x = recoil * 0.2 - drop * 2.0


func _shoot() -> void:
	var w: Dictionary = weapons[cur]
	if int(w["mag"]) <= 0:
		if int(w["reserve"]) == 0:
			set_weapon(0)
		else:
			start_reload()
		return
	w["mag"] = int(w["mag"]) - 1
	fire_cd = float(w["rate"])
	recoil = 1.0
	trauma = minf(1.0, trauma + 0.15) # NUEVO: Añade trauma al disparar
	flash_light.light_energy = 4.0
	flash_mesh.visible = true
	
	# NUEVO: Variación de Pitch en el sonido para más realismo
	game.sfx.play(str(w["snd"]), -2.0, null, randf_range(0.95, 1.05))
	
	game.alert(global_position, 32.0)
	var space := get_world_3d().direct_space_state
	var origin: Vector3 = cam.global_position
	var b: Basis = cam.global_transform.basis
	var sp: float = float(w["spread"])
	for i in int(w["pellets"]):
		var dir: Vector3 = (-b.z + b.x * randfn(0.0, sp) + b.y * randfn(0.0, sp)).normalized()
		var end: Vector3 = origin + dir * 80.0
		var q := PhysicsRayQueryParameters3D.create(origin, end, 3)
		var hit: Dictionary = space.intersect_ray(q)
		if not hit.is_empty():
			end = hit["position"]
			var c = hit["collider"]
			if c != null and c.is_in_group("zombies"):
				var hs: bool = end.y - c.global_position.y > c.head_y
				c.hurt(float(w["dmg"]) * (3.0 if hs else 1.0), hs, dir)
				game.fx_burst(end, Color(0.5, 0.05, 0.05))
			else:
				game.fx_burst(end, Color(0.6, 0.55, 0.45))
		if i < 3:
			game.fx_tracer(muzzle.global_position, end)


func start_reload() -> void:
	if down or reload_t > 0.0:
		return
	var w: Dictionary = weapons[cur]
	if int(w["mag"]) >= int(w["mag_size"]) or int(w["reserve"]) == 0:
		return
	reload_t = float(w["reload"])
	game.sfx.play("click", -2.0)


func _finish_reload() -> void:
	var w: Dictionary = weapons[cur]
	var need: int = int(w["mag_size"]) - int(w["mag"])
	if int(w["reserve"]) < 0:
		w["mag"] = int(w["mag_size"])
	else:
		var take: int = mini(need, int(w["reserve"]))
		w["mag"] = int(w["mag"]) + take
		w["reserve"] = int(w["reserve"]) - take
	game.sfx.play("click", 0.0, null, 0.7)


func set_weapon(i: int) -> void:
	if down or i == cur:
		return
	cur = i
	reload_t = 0.0
	fire_cd = 0.3
	_show_gun()
	game.sfx.play("click", -4.0, null, 1.3)


func next_weapon() -> void:
	set_weapon((cur + 1) % weapons.size())


func shove() -> void:
	if down or shove_cd > 0.0 or not game.playing:
		return
	shove_cd = 0.7
	shove_anim = 1.0
	game.sfx.play("shove", 0.0)
	var fwd: Vector3 = -global_transform.basis.z
	for z in get_tree().get_nodes_in_group("zombies"):
		var to: Vector3 = z.global_position - global_position
		to.y = 0.0
		var d := to.length()
		if d < 2.6 and (d < 0.8 or fwd.dot(to / d) > 0.2):
			z.shove(to.normalized() if d > 0.05 else fwd)


func heal() -> void:
	if down or medkits <= 0 or hp >= 95.0 or not game.playing:
		return
	medkits -= 1
	hp = minf(100.0, hp + 70.0)
	game.sfx.play("pickup", 0.0)
	hud.msg("Botiquín usado", 1.5, Color(0.5, 1.0, 0.5))


func refill() -> void:
	for w in weapons:
		if int(w["reserve_max"]) >= 0:
			w["reserve"] = int(w["reserve_max"])


func bile() -> void:
	bile_t = 6.0


func take_damage(amount: float, from = null) -> void:
	if down or dead or not game.playing:
		return
	hp -= amount
	trauma = minf(1.0, trauma + 0.5) # NUEVO: Añade trauma al recibir daño
	hud.flash = 0.6
	game.sfx.play("hurt", 0.0)
	if from != null and is_instance_valid(from) and from.kind == "bruto":
		var d: Vector3 = global_position - from.global_position
		d.y = 0.0
		knock = d.normalized() * 13.0
		velocity.y = 5.5
	if hp <= 0.0:
		hp = 0.0
		downs += 1
		down = true
		mouse_fire = false
		revive_p = 0.0
		reload_t = 0.0
		if downs >= 3 or not game.any_bot_alive():
			dead = true
			game.game_over(false)
		else:
			hud.msg("¡Has caído! Un compañero viene a reanimarte", 4.0, Color(1.0, 0.4, 0.3))


func revive() -> void:
	down = false
	hp = 30.0
	revive_p = 0.0
	hud.msg("¡De pie! Te quedan %d caídas" % (2 - downs), 3.0, Color(0.5, 1.0, 0.5))