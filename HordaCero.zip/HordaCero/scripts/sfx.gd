extends Node
# Todos los sonidos se generan por codigo: el proyecto no necesita archivos de audio.

const RATE := 22050

var streams := {}
var pool: Array = []
var idx := 0
var listener: Node3D = null
var loop_player: AudioStreamPlayer


func _ready() -> void:
	for i in 12:
		var p := AudioStreamPlayer.new()
		add_child(p)
		pool.append(p)
	loop_player = AudioStreamPlayer.new()
	add_child(loop_player)
	_gen()
	loop_player.stream = streams["wind"]
	loop_player.volume_db = -16.0
	loop_player.play()


func play(sname: String, vol_db := 0.0, at = null, pitch := 1.0) -> void:
	if not streams.has(sname):
		return
	var v := vol_db
	if at != null and listener != null:
		var d: float = listener.global_position.distance_to(at)
		if d > 45.0:
			return
		v -= d * 0.6
	var p: AudioStreamPlayer = pool[idx]
	idx = (idx + 1) % pool.size()
	p.stream = streams[sname]
	p.volume_db = v
	p.pitch_scale = pitch * randf_range(0.94, 1.06)
	p.play()


func _wav(s: PackedFloat32Array, loop := false) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(s.size() * 2)
	for i in s.size():
		data.encode_s16(i * 2, int(clampf(s[i], -1.0, 1.0) * 30000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = s.size()
	return w


func _burst(dur: float, decay: float, lp: float, thump_hz: float, thump_amt: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var s := PackedFloat32Array()
	s.resize(n)
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		y += lp * (randf_range(-1.0, 1.0) - y)
		var env := exp(-t * decay)
		s[i] = (y * 1.6 + sin(TAU * thump_hz * t * (1.0 - t * 0.8)) * thump_amt) * env
	return s


func _voice(dur: float, f0: float, f1: float, vib: float, noise: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var s := PackedFloat32Array()
	s.resize(n)
	var y := 0.0
	var ph := 0.0
	for i in n:
		var t := float(i) / RATE
		var k := t / dur
		var f := lerpf(f0, f1, k) + vib * sin(TAU * 5.0 * t)
		ph += f / RATE
		var saw := fmod(ph, 1.0) * 2.0 - 1.0
		y += 0.3 * (randf_range(-1.0, 1.0) - y)
		var trem := 0.65 + 0.35 * sin(TAU * 13.0 * t)
		s[i] = (saw * 0.45 + y * noise) * trem * sin(PI * k)
	return s


func _mix(a: PackedFloat32Array, b: PackedFloat32Array) -> PackedFloat32Array:
	var n := mini(a.size(), b.size())
	for i in n:
		a[i] = (a[i] + b[i]) * 0.6
	return a


func _gen() -> void:
	streams["shot"] = _wav(_burst(0.22, 22.0, 0.55, 160.0, 0.6))
	streams["rifle"] = _wav(_burst(0.18, 28.0, 0.7, 120.0, 0.5))
	streams["shotgun"] = _wav(_burst(0.45, 11.0, 0.4, 80.0, 0.8))
	streams["explode"] = _wav(_burst(0.7, 6.0, 0.15, 50.0, 0.9))
	streams["hit"] = _wav(_burst(0.07, 50.0, 0.2, 90.0, 0.3))
	streams["shove"] = _wav(_burst(0.12, 30.0, 0.12, 70.0, 0.6))
	streams["click"] = _wav(_burst(0.04, 120.0, 0.9, 900.0, 0.2))
	streams["growl"] = _wav(_voice(0.6, 95.0, 70.0, 14.0, 0.7))
	streams["scream"] = _wav(_voice(0.5, 420.0, 230.0, 30.0, 0.5))
	streams["roar"] = _wav(_voice(1.2, 62.0, 45.0, 6.0, 0.9))
	streams["horde"] = _wav(_mix(_mix(_voice(2.0, 180.0, 240.0, 20.0, 0.6), _voice(2.0, 233.0, 300.0, 26.0, 0.6)), _voice(2.0, 95.0, 120.0, 12.0, 0.8)))
	# dolor del jugador
	var n := int(0.18 * RATE)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / RATE
		s[i] = sin(TAU * (260.0 - 600.0 * t) * t) * exp(-t * 12.0) * 0.8
	streams["hurt"] = _wav(s)
	# recoger objeto
	n = int(0.22 * RATE)
	s = PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / RATE
		var f := 660.0 if t < 0.1 else 990.0
		s[i] = sin(TAU * f * t) * 0.4 * (1.0 - t / 0.22)
	streams["pickup"] = _wav(s)
	# viento de fondo (bucle)
	n = 3 * RATE
	s = PackedFloat32Array()
	s.resize(n)
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		y += 0.03 * (randf_range(-1.0, 1.0) - y)
		s[i] = y * 4.0 * (0.6 + 0.4 * sin(TAU * t / 3.0))
	streams["wind"] = _wav(s, true)
